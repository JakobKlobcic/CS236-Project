//
// Created by jakob on 2/14/2022.
//

#ifndef UNTITLED_SCHEME_H
#define UNTITLED_SCHEME_H

#include <vector>
#include <string>

using namespace std;

class Scheme{
private:
    string name;
    vector<string> idList;
public:
    Scheme(string name, vector<string> idList): name(name), idList(idList){}
    string toString(){
        stringstream ss;
        ss<<name<<"(";
        for(int i = 0; i<(int)(idList.size()); i++){
            ss<<idList.at(i);
            if(i!=(int)(idList.size()-1)){
                ss<<",";
            }
        }
        ss<<")";
        return ss.str();
    }

};
#endif //UNTITLED_SCHEME_H
